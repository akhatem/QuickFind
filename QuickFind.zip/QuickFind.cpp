#include <cstdio>
#include "QuickFindClass.cpp"

int main(int argc, char *argv[]){
		int n ,p, q,num;
		scanf("%d,",&n);
		num = n;
		QuickFind qF(num);
		while(n > 0){
			scanf("%d %d",&p, &q);
			if(p >= num || q >= num){
				printf("OutOfBoundary\n");
				return 0;
			}
			if(!qF.isConnected(p,q)){
				qF.uni(num,p,q);
				printf("%d %d\n", p, q);
			}
			else{
				printf("Already connected.!\n");
			}
			--n;
		}
}





