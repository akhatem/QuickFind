
class QuickFind{
	private:
	int id[1000];
	
 	public:
	QuickFind(int num){
		for(int i = 0; i < num; ++i)
			id[i] = i;
	}
	void uni(int num,int p, int q){
		int pid = id[p];
		int qid = id[q];
		for(int i = 0; i < num; ++i)
			if(id[i] == pid) id[i] = qid;
	}

	bool isConnected(int p, int q){
		return id[p] == id[q];
	}
};
