import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		
		Scanner inN = new Scanner(System.in);
		Scanner inp = new Scanner(System.in);
		Scanner inq = new Scanner(System.in);
		int N = inN.nextInt();
		int num  = N;
		QuickFind qF = new QuickFind(num);
		
		while(N > 0){
			int p = inp.nextInt();
			int q = inq.nextInt();
			if(p >= num || q >= num) {
				System.out.println("OutOfBoundary\n");
				return;
			}
			if(!qF.connected(p, q)){
				qF.union(p, q);
				System.out.println(p + " " + q);
			}
			 else{
					System.out.println("Already connected!");

			} 
			--N;
		}
		inN.close();
		inp.close();
		inq.close();
	}

}
